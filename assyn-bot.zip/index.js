const { Connection, Keypair, PublicKey } = require('@solana/web3.js');
require('dotenv').config();

const connection = new Connection(process.env.QUICKNODE_ENDPOINT, 'confirmed');
const wallet = Keypair.fromSecretKey(Buffer.from(JSON.parse(process.env.PRIVATE_KEY)));
const USDT_MINT_ADDRESS = new PublicKey('Es9vMFrzaCER0J9jBLNqe9dTK8Hb28a7S7np3A48T8z');

async function checkBalances() {
    const balanceSOL = await connection.getBalance(wallet.publicKey);
    console.log('SOL Balance:', balanceSOL / 1e9);

    // Fetch USDT balance
    const usdtBalance = await getTokenBalance(wallet.publicKey, USDT_MINT_ADDRESS);
    console.log('USDT Balance:', usdtBalance);
}

async function getTokenBalance(walletPublicKey, tokenMintAddress) {
    const tokenAccounts = await connection.getParsedTokenAccountsByOwner(walletPublicKey, { mint: tokenMintAddress });
    if (tokenAccounts.value.length > 0) {
        return tokenAccounts.value[0].account.data.parsed.info.tokenAmount.uiAmount;
    }
    return 0;
}

async function arbitrage() {
    console.log('Starting arbitrage bot...');
    await checkBalances();
    // Add your arbitrage logic here

    // Example: Fetch market data, find arbitrage opportunities, execute trades
    // Ensure the bot maintains enough SOL for fees and executes profitable trades
}

arbitrage().catch(console.error);
