# Assyn Arbitrage Bot

## Setup Instructions

1. Clone the repository:
   ```sh
   git clone https://github.com/yourusername/Assyn.git
   cd Assyn
   ```

2. Create a virtual environment:
   ```sh
   python3 -m venv venv
   source venv/bin/activate
   ```

3. Install dependencies:
   ```sh
   pip install -r requirements.txt
   ```

4. Copy the `.env.example` file to `.env` and fill in your details:
   ```sh
   cp .env.example .env
   nano .env
   ```

5. Run the bot:
   ```sh
   python bot.py
   ```

## Deployment as a Systemd Service

1. Create a systemd service file:
   ```sh
   sudo nano /etc/systemd/system/assyn.service
   ```

   Add the following configuration (adjust paths accordingly):
   ```
   [Unit]
   Description=Assyn Arbitrage Bot
   After=network.target

   [Service]
   User=root
   WorkingDirectory=/path/to/Assyn
   Environment="PYTHONPATH=/path/to/Assyn"
   EnvironmentFile=/path/to/Assyn/.env
   ExecStart=/path/to/Assyn/venv/bin/python /path/to/Assyn/bot.py
   Restart=always

   [Install]
   WantedBy=multi-user.target
   ```

2. Start and enable the service:
   ```sh
   sudo systemctl daemon-reload
   sudo systemctl start assyn
   sudo systemctl enable assyn
   ```

## Monitoring and Logging

Monitor logs:
```sh
journalctl -u assyn -f
```

## Backup and Recovery

Automate backups using cron jobs:
```sh
crontab -e
```

Add the following line for daily backup:
```sh
0 2 * * * tar -czf /backup/arbitrage-bot-$(date +\%F).tar.gz /path/to/Assyn
```
