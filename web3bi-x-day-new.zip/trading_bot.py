
import ccxt
import os
import time
import logging
from config import INITIAL_BALANCE_SOL, INITIAL_BALANCE_USDT, REOPTIMIZE_THRESHOLD, PROFIT_GOAL_PERCENT

logging.basicConfig(filename='trading_bot.log', level=logging.INFO, format='%(asctime)s %(message)s')

api_key = os.getenv('OKX_API_KEY')
api_secret = os.getenv('OKX_API_SECRET')
api_password = os.getenv('OKX_API_PASSWORD')

exchange = ccxt.okx({
    'apiKey': api_key,
    'secret': api_secret,
    'password': api_password,
    'enableRateLimit': True,
})

balance_sol = INITIAL_BALANCE_SOL
balance_usdt = INITIAL_BALANCE_USDT
