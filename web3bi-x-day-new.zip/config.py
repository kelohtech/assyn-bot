
# Configuration settings for the trading bot

# Initial balances
INITIAL_BALANCE_SOL = 5.0
INITIAL_BALANCE_USDT = 100.0

# Balance re-optimization threshold
REOPTIMIZE_THRESHOLD = 50.0

# Profit goal
PROFIT_GOAL_PERCENT = 300.0  # 300% increase hour over hour
