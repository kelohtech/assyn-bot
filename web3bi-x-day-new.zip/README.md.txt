
# OKX Trading Bot

## Overview
This trading bot interacts with the OKX exchange using the CCXT library. It automates trading based on predefined strategies and indicators. The bot calculates technical indicators, generates trading signals, and places orders on the exchange.

## Requirements
- Python 3.x
- CCXT library
- Pandas library
- NumPy library

## Setup
1. **Install the required libraries**:
    ```sh
    pip install ccxt pandas numpy
    ```

2. **Set your OKX API credentials as environment variables**:
    - On Unix-based systems (Linux, macOS):
        ```sh
        export OKX_API_KEY='your_api_key'
        export OKX_API_SECRET='your_api_secret'
        export OKX_API_PASSWORD='your_api_password'
        ```
    - On Windows:
        ```cmd
        setx OKX_API_KEY "your_api_key"
        setx OKX_API_SECRET "your_api_secret"
        setx OKX_API_PASSWORD "your_api_password"
        ```

3. **Run the trading bot**:
    ```sh
    python trading_bot.py
    ```

## Deployment
To deploy the bot on a server using Putty:

1. **Connect to your server using Putty**.
2. **Transfer the bot files to your server** using SCP or any file transfer method.
3. **Set up the environment variables on the server**.
4. **Run the bot in the background**:
    ```sh
    nohup python trading_bot.py &
    ```

## Monitoring
Check the `trading_bot.log` file for logs and updates on the bot's performance and activities.
